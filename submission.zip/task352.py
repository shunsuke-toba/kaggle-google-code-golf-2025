def p(j,A=enumerate):
 c=[[l for J,l in A(k)]for k in j]
 for E,k in A(j):
  for W,l in A(k):
   if l==2:
    for J in range(-1,2):
     for a in range(-1,2):
      try:
       if[J,a]!=[0,0]and E+J>-1and W+a>-1:c[E+J][W+a]=1
      except:0
 return c